﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;

namespace Client
{
    class Program
    {
        
        static BusinessLayer.BusinessLayer bl = new BusinessLayer.BusinessLayer();
        
        public static void Main(string[] args)
        {
            //----------------------------------------- Slots ------
            //static?

            //SearchStandardStudents();
            string teacherName;
            int teacherID;
            int standardID;
            int newTeacherID;

            string courseName;
            int courseID;

            bool doTeachers = false;
            bool doCourses = false;
            bool doGame = true;

            int choice;
            String num;


            //Menu for the user to make modifications
            while (doGame == true)
            {
                Console.WriteLine("Modify 1. Teachers or 2. Courses?");
                choice = Convert.ToInt32(Console.ReadLine());
               // num = Console.ReadLine();
               // choice = Int32.Parse(num);

                if (choice == 1)
                {
                    doTeachers = true;
                    doCourses = false;
                }
                else if (choice == 2)
                {
                    doCourses = true;
                    doTeachers = false;
                }
                else {
                    Console.WriteLine("?????");
                }
                    

                while (doTeachers == true)
                {
                    menu1();
                    Console.WriteLine("");
                    //choice = Convert.ToInt32(Console.ReadLine());
                    num = Console.ReadLine();
                    choice = Int32.Parse(num);
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("- CREATE - ");
                            Console.WriteLine("Enter Teacher Name: ");
                            teacherName = Console.ReadLine();
                            Console.WriteLine("Enter Standard ID: ");
                            //standardID = Console.Read();
                            standardID = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter Teacher ID: ");
                            //teacherID = Console.Read();
                            teacherID = Convert.ToInt32(Console.ReadLine());
                            createTeacher(teacherName, standardID, teacherID);
                            break;
                        case 2:
                            Console.WriteLine(" - UPDATE - ");
                            Console.WriteLine("Enter Teacher ID of Teacher you want to update: ");
                            teacherID = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter New Teacher Name: ");
                            teacherName = Console.ReadLine();
                            //Console.WriteLine("Enter Teacher ID: ");
                            //teacherID = Convert.ToInt32(Console.ReadLine());
                            updateTeacher(teacherName, teacherID);
                            break;
                        case 3:
                            Console.WriteLine("- DELETE - ");
                            Console.Write("Enter Teacher ID: ");
                            teacherID = Convert.ToInt32(Console.ReadLine());
                            deleteTeacher(teacherID);
                            break;
                        case 4:
                            Console.WriteLine("- GET COURSES BY TEACHER ID");
                            Console.Write("Enter Teacher ID: ");
                            teacherID = Convert.ToInt32(Console.ReadLine());
                            GetCourseByTeacherID(teacherID);
                            break;
                        case 5:
                            Console.WriteLine("- GET ALL TEACHERS");
                            GetAllTeachers();
                            break;
                        case 6:
                            Console.WriteLine("- GET ALL STANDARDS -");
                            GetAllStandards();
                            break;
                        case 7:
                            doTeachers = false;
                            doCourses = false;
                            break;
                    }

                }

                while (doCourses == true)
                {
                    menu2();
                    Console.WriteLine("");
                    choice = Convert.ToInt32(Console.ReadLine());
                    //num = Console.ReadLine();
                   // choice = Int32.Parse(num);
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("- CREATE COURSE -");
                            Console.WriteLine("Enter Course Name: ");
                            courseName = Console.ReadLine();
                            Console.WriteLine("Enter Course ID: ");
                            //courseID = Console.Read();
                            courseID = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter Teacher ID: ");
                            //teacherID = Console.Read();
                            teacherID = Convert.ToInt32(Console.ReadLine());
                            createCourse(courseName, courseID, teacherID);
                            break;
                        case 2:
                            Console.WriteLine("- UPDATE COURSE -");
                            Console.WriteLine("Enter Course ID of Course you want to Update: ");
                            courseID = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter New Course Name: ");
                            courseName = Console.ReadLine();
                            updateCourse(courseName, courseID);
                            break;
                        case 3:
                            Console.WriteLine("- DELETE COURSE -"); 
                            Console.WriteLine("Enter Course ID");
                            courseID = Convert.ToInt32(Console.ReadLine());
                            deleteCourse(courseID);
                            break;
                        case 4:
                            Console.WriteLine("- DISPLAY ALL COURSES - ");
                            getAllCourses();
                            break;
                        case 5:
                            doTeachers = false;
                            doCourses = false;
                            break;
                    }
                }
            }
           


        }

        private static void menu1()
        {
            Console.Write("1. CREATE " +
                        "\n2. UPDATE " +
                        "\n3. DELETE " +
                        "\n4. LIST COURSES BY TEACHER ID " +
                        "\n5. ALL TEACHERS " +
                        "\n6. ALL STANDARDS " +
                        "\n7. MAIN MENU");
        }

        private static void menu2()
        {
            Console.Write("1. CREATE " +
                        "\n2. UPDATE " +
                        "\n3. DELETE " +
                        "\n4. ALL COURSES " +
                        "\n5. MAIN MENU");
        }

        /// <summary>
        /// Creates a teacher to add into the database
        /// </summary>
        /// <param name="tName">Name of the teacher</param>
        /// <param name="sID">Standard ID</param>
        /// <param name="tID">Teacher ID</param>
        private static void createTeacher(string tName, int sID, int tID)
        {
            Console.Write("Create \n");
            if (bl == null)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
          
            Teacher teacher = new Teacher();
            teacher.TeacherName = tName;
            teacher.StandardId = sID;
            teacher.TeacherId = tID;
            bl.AddTeacher(teacher); //this?
                
        }

        /// <summary>
        /// Updates teacher in the database
        /// </summary>
        /// <param name="tName">Name of the teacher</param>
        /// <param name="tID">Teacher ID</param>
        private static void updateTeacher(string tName, int tID)
        {
            Console.Write("Update \n");
            if (bl == null)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            Teacher teacher = bl.GetTeacherByID(tID);
            teacher.TeacherName = tName;

            //check function so it knows which one to update
            bl.UpdateTeacher(teacher);

        }

        /// <summary>
        /// Deletes a teacher in the database
        /// </summary>
        /// <param name="tID">Teacher ID</param>
        private static void deleteTeacher(int tID)
        {
            Console.Write("Delete \n");
            Teacher teacher = bl.GetTeacherByID(tID);
            if (bl == null)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            else if (teacher == null)
            {
                Console.WriteLine("Course does not exist!");
                return;
            }
            bl.RemoveTeacher(teacher);
        }

        /// <summary>
        /// Gets courses that the teacher teaches
        /// </summary>
        /// <param name="tID">Teacher ID</param>
        private static void GetCourseByTeacherID(int tID)
        {
            Console.WriteLine("Get Course By Teacher ID");
            foreach(Course i in bl.GetCourseByTeacherID(tID))
            {
                Console.WriteLine("- " + i.CourseName);
            }
        }

        /// <summary>
        /// Gets all the teachers
        /// </summary>
        private static void GetAllTeachers()
        {
            Console.Write("All Teachers \n ");
            
            if (bl == null)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            else if (bl.GetAllTeachers() == null || bl.GetAllTeachers().Count == 0)
            {
                Console.WriteLine("List has no teachers!");
                return;
            }
            IList<Teacher> list = bl.GetAllTeachers();
            Console.WriteLine("\nContaining Teachers: {0}", bl.GetAllTeachers().Count);
            foreach (Teacher i in bl.GetAllTeachers())
                Console.WriteLine("- " + i.TeacherName + " | tID: " + i.TeacherId + " | sID: " + i.StandardId);

        }

        /// <summary>
        /// Gets all the standards
        /// </summary>
        private static void GetAllStandards()
        {
            Console.Write("All Teachers \n ");

            IEnumerable<Standard> list = bl.GetAllStandards();
            if (bl == null)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            else if (bl.GetAllStandards() == null)
            {
                Console.WriteLine("List has no standards!");
                return;
            }

            foreach(Standard i in bl.GetAllStandards())
                Console.WriteLine("- " + i.StandardName  + " | sID: " + i.StandardId);

        }

        /// <summary>
        /// Creates a course
        /// </summary>
        /// <param name="cName">Course Name</param>
        /// <param name="cID">Course ID</param>
        /// <param name="tID">Teacher ID</param>
        private static void createCourse(string cName, int cID, int tID)
        {
            Console.Write("Create Course \n");
            if (bl == null)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            Course course = new Course();
            course.CourseId = cID;
            course.CourseName = cName;
            course.TeacherId = tID;
            bl.AddCourse(course);
            Console.WriteLine("Done");
        }

        /// <summary>
        /// Updates a course
        /// </summary>
        /// <param name="cName">Course Name</param>
        /// <param name="cID">Course ID</param>
        /// <param name="tID">Teacher ID</param>
        private static void updateCourse(string cName, int cID)
        {
            Console.Write("Update Course \n");
            Course course = bl.GetCourseByID(cID);
            if (bl == null)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            else if (course == null)
            {
                Console.WriteLine("Course does not exist!");
                return;
            }
            course.CourseName = cName;
            bl.UpdateCourse(course);
            Console.WriteLine("Course successfully updated");
        }

        /// <summary>
        /// Deletes a course in the database
        /// </summary>
        /// <param name="cID">Course ID</param>
        private static void deleteCourse(int cID)
        {
            Console.Write("Delete Course \n");
            Course course = bl.GetCourseByID(cID);
            if(bl == null)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            else if(course == null)
            {
                Console.WriteLine("Course does not exist!");
                return;
            }
            bl.RemoveCourse(course);
            Console.WriteLine("Course successfully removed");
            
        }

        /// <summary>
        /// Gets all the courses in the database
        /// </summary>
        private static void getAllCourses()
        {
            Console.Write("Get all courses \n");

            if (bl == null)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            else if (bl.GetAllCourses() == null || bl.GetAllCourses().Count == 0)
            {
                Console.WriteLine("List has no Courses!");
                return;
            }

            Console.WriteLine("\nContaining Courses: {0}", bl.GetAllCourses().Count);
            foreach (Course i in bl.GetAllCourses())
            {
                Console.Write(i.CourseName + " | cID: " + i.CourseId + " | tID: " + i.TeacherId + "\n");
            }
        }

        //Unused
        private static void SearchStandardStudents()
        {
            Console.Write("Enter Standard ID: ");
            ReadChoice();
            Standard s = bl.GetStandardByIDWithStudents(111);
            if (s == null)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            else if (s.Students == null || s.Students.Count == 0)
            {
                Console.WriteLine("This Standard has no Students!");
                return;
            }

            Console.WriteLine("\nContaining Students: {0}", s.Students.Count);
            foreach (Student student in s.Students)
                Console.WriteLine("- " + student.StudentName);

        }
        //unused
        private static void ReadChoice()
        {
            Console.WriteLine("Enter the ID");
            //choice = Console.Read();
        }
    }
}
